﻿namespace SharedKernel;

public interface IDomainEvent;
